<?php
include 'includes/db.php';
$id = $_GET["id"];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $conn->query("UPDATE users SET nombre='$nombre', email='$email' WHERE id=$id");
    header("Location: index.php");
}
$result = $conn->query("SELECT * FROM users WHERE id=$id");
$row = $result->fetch_assoc();
?>
<form method="post">
    <input type="text" name="nombre" value="<?= $row['nombre'] ?>" required>
    <input type="email" name="email" value="<?= $row['email'] ?>" required>
    <button type="submit">Actualizar</button>
</form>
