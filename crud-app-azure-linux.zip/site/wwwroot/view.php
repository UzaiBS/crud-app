<?php
include 'includes/db.php';
$id = $_GET["id"];
$result = $conn->query("SELECT * FROM users WHERE id=$id");
$row = $result->fetch_assoc();
?>
<h2>Detalles del Usuario</h2>
<p><strong>Nombre:</strong> <?= $row['nombre'] ?></p>
<p><strong>Email:</strong> <?= $row['email'] ?></p>
<a href="index.php">Volver</a>
