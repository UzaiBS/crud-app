<?php
include 'includes/db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $conn->query("INSERT INTO users (nombre, email) VALUES ('$nombre', '$email')");
    header("Location: index.php");
}
?>
<form method="post">
    <input type="text" name="nombre" placeholder="Nombre" required>
    <input type="email" name="email" placeholder="Email" required>
    <button type="submit">Agregar</button>
</form>
